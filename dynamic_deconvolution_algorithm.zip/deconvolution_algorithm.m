
function [k_cell_type_freq,s_cell_type_activation]=deconvolution_algorithm(bulk_mat_filename)

load cell_types_marker_genes_from_sc_data

if strcmp('demo',bulk_mat_filename)
    load samll_dataset_to_demo
elseif exist(bulk_mat_filename)
    eval(['load ',bulk_mat_filename])   
elseif exist([bulk_mat_filename,'.mat'])
    eval(['load ',bulk_mat_filename,'.mat'])  
else
    error(['No such mat file <', bulk_mat_filename,'>; You can use demo file by input ''demo'' instead of the file name'])
end

%extract shared genes between bulk and single cell data and reorder: 
[tf_genes,i_genes]=ismember(exp_genes,candidate_genes_both);
bulk_genes=exp_genes(tf_genes);
bulk_data=exp_data(tf_genes,:);

sc_data_exp=candidate_data_both_mean(i_genes(i_genes~=0),:);
sc_data_genes=candidate_genes_both(i_genes(i_genes~=0));


%estimate cell types composition/infection induced state:
%----------------------------------------------
%NK cells:
tf_NK_genes=ismember(bulk_genes,NK_cell_type); 
curr_NK_genes=bulk_genes(tf_NK_genes);
n_NK=bulk_data(tf_NK_genes,:)./repmat(sc_data_exp(tf_NK_genes,1),1,size(bulk_data,2));
NK_freq_per_sample=mean(n_NK);

%NKT cells:
tf_NKT_genes=ismember(bulk_genes,NKT_infection_induced);
curr_NKT_genes=bulk_genes(tf_NKT_genes);
n_NKT=bulk_data(tf_NKT_genes,:)./repmat(sc_data_exp(tf_NKT_genes,2),1,size(bulk_data,2));
NKT_state_per_sample=mean(n_NKT);

%T cells:
tf_T_genes=ismember(bulk_genes,T_cell_type);
curr_T_genes=bulk_genes(tf_T_genes);
n_T=bulk_data(tf_T_genes,:)./repmat(mean(sc_data_exp(tf_T_genes,3:4),2),1,size(bulk_data,2));
T_freq_per_sample=mean(n_T);

%B cells:
tf_B_genes=ismember(bulk_genes,B_cell_type); 
curr_B_genes=bulk_genes(tf_B_genes);
n_B=bulk_data(tf_B_genes,:)./repmat(sc_data_exp(tf_B_genes,5),1,size(bulk_data,2));
B_freq_per_sample=mean(n_B);

%Monocytes:
%cell type:
tf_mono_genes=ismember(bulk_genes,mono_cell_type);
curr_mono_genes=bulk_genes(tf_mono_genes);
n_mono=bulk_data(tf_mono_genes,:)./repmat(sc_data_exp(tf_mono_genes,6),1,size(bulk_data,2));
mono_freq_per_sample=mean(n_mono);

%infection induced state:
tf_mono_genes_act=ismember(bulk_genes,mono_infection_induced);
curr_mono_genes_act=bulk_genes(tf_mono_genes_act);
n_mono=bulk_data(tf_mono_genes_act,:)./repmat(sc_data_exp(tf_mono_genes_act,6),1,size(bulk_data,2));
mono_state_per_sample=mean(n_mono);


%DC cells:
tf_DC_genes=ismember(bulk_genes,DC_cell_type); 
curr_DC_genes=bulk_genes(tf_DC_genes);
n_DC=bulk_data(tf_DC_genes,:)./repmat(sc_data_exp(tf_DC_genes,7),1,size(bulk_data,2));
DC_freq_per_sample=mean(n_DC);

%summarize estimated cell types freq.:
Sample=exp_samples';
NK=NK_freq_per_sample';
T=T_freq_per_sample';
B=B_freq_per_sample';
Monocytes=mono_freq_per_sample';
DC=DC_freq_per_sample';
k_cell_type_freq=table(Sample,NK,T,B,Monocytes,DC)
writetable(k_cell_type_freq,'cell_type_freq.txt');

%summarize estimated cell types infection-induced state:
NKT=NKT_state_per_sample';
Monocytes=mono_state_per_sample';
s_cell_type_activation=table(Sample,NKT,Monocytes)
writetable(s_cell_type_activation,'cell_type_activation.txt');

